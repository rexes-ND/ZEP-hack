let is_built = false;

var stall_list = [];
for (let i = 0; i < 8; i++){
    if (i < 6){
        stall_list.push(0);
        stall_list.push(0);
    } else if (i == 6){
        stall_list.push(14);
        stall_list.push(32);
    } else if (i == 7){
        stall_list.push(6);
        stall_list.push(26);
    }
};

// original should also be read from the filesys!!
var original = [1, 1, 1, 1, 0, 0, 0, 0];
// if (App.storage != "test"){
//     App.storage = "test";
//     App.save();
// } else{
//     original =  [1, 1, 1, 1, 1, 1, 0, 1];
// }

// if (_players != 1){
//     var original = [1, 1, 1, 1, 1, 1, 1, 0];
// }


var stall_maps = ["2Ndw4X", "8lPJnr"]
var response_received = true


App.onJoinPlayer.Add(function(player){
// App.onUpdate.Add(function(dt) {
    // startState(STATE_INIT);
    // App.showCenterLabel(`${original}`)
    App.httpGet(
		"https://morning-everglades-39102.herokuapp.com/",
		null,
		function (res) {
			// Change the response to a json object
			let response = JSON.parse(res);
            // App.showCenterLabel(response.length == 1)
            original = [1, 1, 1, 1, 1, 1, 0, 0];
            if (response.length ==2){
                original = [1, 1, 1, 1, 1, 1, 0, 0];
            }


        let object = App.loadSpritesheet('res/icon.png')


        if(!response_received){
            return;
        }
        
        var empty_stall = original.indexOf(0);
        if (empty_stall == 6){
            var map_no = stall_maps[0];
        }
        else if (empty_stall == 7){
            var map_no = stall_maps[1];
        }
        else if (empty_stall == -1){
            App.showCenterLabel(`Stall space is fully occupied!!`)
        }
        x_first = empty_stall*2;
        y_first = empty_stall*2+1;

        x_first = stall_list[x_first];
        y_first = stall_list[y_first];

        Map.putObject(x_first, y_first, object, {
            overlap: true,
            });


        for(let i =x_first-1; i < (x_first+5); i++){
            for(let j =y_first; j < (y_first+5); j++){
                
                App.addOnTileTouched(i, j, function (player) {
                    App.showCenterLabel(`Enter mobile store!`);
                });

                Map.putTileEffect(i, j, TileEffectType.SPACE_PORTAL, {
                    targetMapID: "8rKnVa",
                    invisible: true,
                })
            }
        }

        // when q is pressed
        App.addOnKeyDown(81, function (player) {
            for(let i =x_first-1; i < (x_first+5); i++){
                for(let j =y_first; j < (y_first+5); j++){
                    Map.putObject(i, j, null, {overlap: true});
                }
            }
            });

        response_received = false;

    });
    
});
